package com.cg.product.repo;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.product.pojo.ProductDto;

@Repository
@Transactional
public class ProductRepo implements IProductRepo{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	@Transactional
	public List<ProductDto> viewAll() {
		// TODO Auto-generated method stub
		
		TypedQuery<ProductDto> query=entityManager.createQuery("select prod from ProductDto prod ", ProductDto.class);  // for retrieving the data from table
						
					List<ProductDto> list= query.getResultList();
				return list;		// returning a all values in the form of list
		
	}

	@Override
	@Transactional
	public ProductDto create(ProductDto productdto) {
				
		 entityManager.persist(productdto);				// for inserting the value
		 return productdto;
	}

	@Override
	@Transactional
	public ProductDto findProduct(String id) {
		
		ProductDto productdto= entityManager.find(ProductDto.class, id);		// to find the element from database
		return productdto;
	}

	@Override
	@Transactional
	public ProductDto update( String id,ProductDto productdto) {
		// 
		
		entityManager.merge(productdto);		// to update the element  from database
		return productdto;

	}

	@Override
	@Transactional
	public ProductDto delete(String id) {
		ProductDto product= entityManager.find(ProductDto.class, id);
		entityManager.remove(product);		// to remove the id 
		return product;
		 
	}
	
	
	
	
	
	
	
	
	
}
