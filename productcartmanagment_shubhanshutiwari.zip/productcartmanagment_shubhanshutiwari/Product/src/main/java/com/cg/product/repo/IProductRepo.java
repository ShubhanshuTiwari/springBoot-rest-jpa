package com.cg.product.repo;

import java.util.List;

import com.cg.product.pojo.ProductDto;

public interface IProductRepo {

	public List<ProductDto> viewAll();
	public ProductDto create(ProductDto productdto);
	public ProductDto findProduct(String id);
	public ProductDto update(String id,ProductDto productdto);
	public ProductDto delete(String id);
}
