package com.cg.product.Product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.cg.product.exception.NamePatternException;
import com.cg.product.pojo.ProductDto;
import com.cg.product.service.ProductService;

@RestController
public class ProductController {

	@Autowired(required=true)
	private ProductService serviceref;
	
	@RequestMapping(method=RequestMethod.GET,value="products")
	public List<ProductDto> viewAll(){
		return serviceref.viewAll();
	}
	
	@RequestMapping(method=RequestMethod.POST,value="products")
	public ProductDto create(@RequestBody ProductDto productdto) {
		return serviceref.create(productdto);
		}
	
	@RequestMapping(method=RequestMethod.GET,value="products/{id}")
	public ProductDto findProduct(@PathVariable String id) {
		return serviceref.findProduct(id);
		}
	
	@RequestMapping(method=RequestMethod.PUT,value="products/{id}")
	public ProductDto update(@PathVariable String id,@RequestBody ProductDto productdto) {
		return serviceref.update(id, productdto);
		}
	
	@RequestMapping(method=RequestMethod.DELETE,value="products/{id}")
	public ProductDto delete(@PathVariable String id) {
		return serviceref.delete(id);
		}
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Enter First letter Capital name.")
	@ExceptionHandler({NamePatternException.class})
	public void handleNameException() {
		
	}
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Enter Id in pattern first letter small than numeric ")
	@ExceptionHandler({NamePatternException.class})
	public void handleIdException() {
		
	}
	
}
