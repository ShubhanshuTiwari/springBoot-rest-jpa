package com.cg.product.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.exception.NamePatternException;
import com.cg.product.pojo.ProductDto;
import com.cg.product.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired(required=true)
	ProductRepo productrepo;
	public List<ProductDto> viewAll(){
		return productrepo.viewAll() ;	// to call the repo class
	}
	public ProductDto create(ProductDto productdto) {
		
		
		String name=productdto.getName();
		Pattern namePat=Pattern.compile("^[A-Z]{1}[a-z]+$"); // Regular Expression for matching the product name pattern
		Matcher nameMa=namePat.matcher(name);
		if(nameMa.matches()==false) {
		throw new NamePatternException();
		}
		
		return productrepo.create(productdto);		// to call the repo class
	}
	public ProductDto findProduct(String id) {
		return productrepo.findProduct(id);		// to call the repo class
	}
	public ProductDto update(String id,ProductDto productdto) {
		return productrepo.update(id, productdto);		// to call the repo class
		
	}
	public ProductDto delete(String id) {
		return productrepo.delete(id);		// to call the repo class
		
	}
}
