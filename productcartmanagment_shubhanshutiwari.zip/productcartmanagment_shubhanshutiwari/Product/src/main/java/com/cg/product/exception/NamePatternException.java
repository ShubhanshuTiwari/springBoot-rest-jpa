package com.cg.product.exception;

public class NamePatternException extends RuntimeException {

	
	
}


